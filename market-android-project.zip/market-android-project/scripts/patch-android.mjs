import fs from 'node:fs';
const manifest = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(manifest)) throw new Error('Android manifest not found. Run npx cap add android first.');
let xml = fs.readFileSync(manifest, 'utf8');
const permissions = [
  '  <uses-permission android:name="android.permission.CAMERA" />',
  '  <uses-permission android:name="android.permission.USE_BIOMETRIC" />',
  '  <uses-permission android:name="android.permission.USE_FINGERPRINT" />',
  '  <uses-permission android:name="android.permission.INTERNET" />'
];
for (const p of permissions) { const name = p.match(/android:name="([^"]+)/)[1]; if (!xml.includes(name)) xml = xml.replace('<application', `${p}\n    <application`); }
fs.writeFileSync(manifest, xml);
console.log('Android permissions configured.');
