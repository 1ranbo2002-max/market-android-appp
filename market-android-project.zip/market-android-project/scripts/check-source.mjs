import fs from 'node:fs';
import vm from 'node:vm';
const html = fs.readFileSync('source/index.html', 'utf8');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(m => m[1]).filter(s => s.trim());
for (const [i, script] of scripts.entries()) new vm.Script(script, { filename: `inline-script-${i + 1}.js` });
console.log(`Syntax check passed for ${scripts.length} inline script blocks.`);
