import { NativeBiometric } from '@capgo/capacitor-native-biometric';

(async () => {
  const addButton = () => {
    const screen = document.getElementById('securityScreen');
    if (!screen || document.getElementById('nativeBiometricButton')) return;
    const button = document.createElement('button');
    button.id = 'nativeBiometricButton';
    button.className = 'btn secondary';
    button.type = 'button';
    button.textContent = 'فتح بالبصمة';
    button.style.cssText = 'display:block;width:100%;margin-top:10px';
    button.addEventListener('click', async () => {
      try {
        const availability = await NativeBiometric.isAvailable();
        if (!availability.isAvailable) { alert('البصمة غير متاحة على هذا الجهاز. استخدم PIN أو كلمة المرور.'); return; }
        await NativeBiometric.verifyIdentity({ reason: 'فتح دفتر ديون الماركت', title: 'التحقق بالبصمة', subtitle: 'استخدم بصمة الهاتف', description: 'تأكيد الهوية' });
        screen.classList.remove('show');
        const splash = document.getElementById('splashScreen');
        if (splash) splash.classList.add('hide');
      } catch (e) { console.log('Biometric verification cancelled or unavailable', e); }
    });
    const submit = document.getElementById('lockSubmit');
    if (submit?.parentElement) submit.parentElement.appendChild(button); else screen.appendChild(button);
  };
  addButton();
  const observer = new MutationObserver(addButton);
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
